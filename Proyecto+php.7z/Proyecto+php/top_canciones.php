<!DOCTYPE html>
<html>
  <meta charset="UTF-8">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/css.css">
</head>

<body>
    <div class="flex-container">
        <div class="flex-container1"><img src="images/aj.jpg" height="250px"> </img></div>
        <div class="flex-container2"><p class="ajtexto">ANTONIO JOSÉ</p></div>
        </div>
        <div class="navbar">
          <a href="">Top canciones</a>
        <div class="navbar">
        <a href="Proyecto1.html">Volver</a>     
    </div>
    <div>
      <form action="index2.php" method="POST">
          <p> <label for="cancion">Cancion</label>
              <input type="text" name="cancion">
          </p>
          <p> <label for="disco">Disco</label>
              <input type="text" name="disco">
          </p>
          <p><button>Añadir</button></p>
      </form>
    </div>
</body>

</html>